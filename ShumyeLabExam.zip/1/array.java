import java.util.Scanner;

public class array {
    int[]numbers = new int[5];
    public static void main(String[] args) {
        int[]numbers = new int[5];
        Scanner sc = new Scanner(System.in);
        System.out.println("populate an array");
        for (int i = 0; i < numbers.length; i++) {
            int num = sc.nextInt();
            numbers[i] = num;
        }
        System.out.println("Enter number to be searched.");
        int numberToBeSearched = sc.nextInt();
        int count = 0;
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] == numberToBeSearched){
                count += 1;
            }
        }
        System.out.println(numberToBeSearched + "exists" + count + "times");
    }
}
