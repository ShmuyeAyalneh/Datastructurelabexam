public class arrayDeletion {
    public int[] deleteElement(int[]array, int index){
        int[] newArray = new int[array.length - 1];
        if (index >= array.length || array.length < 0) {
            System.out.println("invalid index");
        }
        for (int i = 0, j = 0; i < array.length; i++) {
            if (i != index) {
                newArray[j++] = array[i];
            }
        }
        return newArray;
    }

}
