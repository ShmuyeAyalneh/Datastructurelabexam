class QuequeUsingStacks2 {
    private int maxSize;
    private char[] stackArray;
    private int top;

    public QuequeUsingStacks2(int maxSize) {
        this.maxSize = maxSize;
        this.stackArray = new char[maxSize];
        this.top = -1;
    }

    public void push(char value) {
        if (top == maxSize - 1) {
            System.out.println("QuequeUsingStacks2 Overflow");
            return;
        }
        stackArray[++top] = value;
    }

    public char pop() {
        if (top == -1) {
            System.out.println("QuequeUsingStacks2 Underflow");
            return '\0'; // Return null character if stack is empty
        }
        return stackArray[top--];
    }

    public char peek() {
        if (top == -1) {
            System.out.println("QuequeUsingStacks2 is empty");
            return '\0'; // Return null character if stack is empty
        }
        return stackArray[top];
    }

    public boolean isEmpty() {
        return (top == -1);
    }
}

class QueueUsingTwoStacks {
    private QuequeUsingStacks2 stack1;
    private QuequeUsingStacks2 stack2;

    public QueueUsingTwoStacks(int maxSize) {
        stack1 = new QuequeUsingStacks2(maxSize);
        stack2 = new QuequeUsingStacks2(maxSize);
    }

    public void enqueue(char value) {
        while (!stack1.isEmpty()) {
            stack2.push(stack1.pop());
        }
        stack1.push(value);
        while (!stack2.isEmpty()) {
            stack1.push(stack2.pop());
        }
    }

    public char dequeue() {
        if (stack1.isEmpty()) {
            System.out.println("Queue is empty");
            return '\0'; // Return null character if queue is empty
        }
        return stack1.pop();
    }

    public char peek() {
        if (stack1.isEmpty()) {
            System.out.println("Queue is empty");
            return '\0'; // Return null character if queue is empty
        }
        return stack1.peek();
    }
}


    public static void main(String[] args) {
        QueueUsingTwoStacks queue = new QueueUsingTwoStacks(5);
        queue.enqueue('A');
        queue.enqueue('B');
        queue.enqueue('C');

        System.out.println("Peek: " + queue.peek());
        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println("Peek: " + queue.peek());

        queue.enqueue('D');
        queue.enqueue('E');

        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println("Dequeue: " + queue.dequeue());

}
